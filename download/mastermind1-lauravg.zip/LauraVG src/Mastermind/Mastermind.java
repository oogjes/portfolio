package Mastermind;


import java.util.*;

public class Mastermind {
    private static Random random = new Random();
    private static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
	
	// All colors:
        String[] colorComb = new String[4];
        String[] allColors = {"R", "O", "Y", "G", "B", "P"};

        // If there are correct black or white ones:
        boolean[] correctBlack = new boolean[4];
        boolean[] correctWhite = new boolean[4];

        // Computer chooses 4 random colors:
        for (int i = 0; i < 4; i++) {
            colorComb[i] = allColors[random.nextInt(allColors.length)];
        }

        boolean won = false;

        // Checking if the player has won:
        for (int round = 1; round < 10 && !won; round++) {
            System.out.println("This is round " + round);
            String[] playerComb = new String[4];

            System.out.println("Colors: R-O-Y-G-B-P");
            System.out.println("Choose a color combination 1 by 1 (In caps):");

            // Getting the player's input:
            for (int i = 0; i < 4; i++) {
                playerComb[i] = input.nextLine();
            }

            // Compare colors:
            int bCorrect = 0;
            int wCorrect = 0;
            
            for (int i = 0; i < 4; i++) {
                if (playerComb[i].equals(colorComb[i])) {
                    if (!correctBlack[i]) {
                        bCorrect++;
                        correctBlack[i] = true;
                    }
                } else {
                    for (int j = 0; j < 4; j++) {
                        if (playerComb[i].equals(colorComb[j]) && !correctWhite[i]) {
                            wCorrect++;
                            correctWhite[i] = true;
                            break;
                        }
                    }
                }
            }

            // Check if all 4 are correct:
            if (bCorrect == 4) {
                won = true;
            } else {
        	
                // Reset for next round:
                resetCorrectFlags(correctBlack);
                resetCorrectFlags(correctWhite);
                
                System.out.println("Black:" + bCorrect);
                System.out.println("White:" + wCorrect);
            }
        }

        System.out.println(won ? "You won!!!" : "You lost!!!");
    }
    
    // Reset for next round as well:
    private static void resetCorrectFlags(boolean[] flags) {
        for (int i = 0; i < flags.length; i++) {
            flags[i] = false;
            
        }
    }
}
