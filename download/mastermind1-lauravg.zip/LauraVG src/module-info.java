/**
 * 
 */
/**
 * 
 */
module Mastermind
{
}